import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { O as require_jsx_runtime, a as Overlay2, c as Title2, d as DialogContent$1, f as DialogDescription$1, h as DialogTitle$1, i as Description2, l as Dialog$1, m as DialogPortal$1, n as Cancel, o as Portal2, p as DialogOverlay$1, r as Content2, s as Root2, t as Action, u as DialogClose, w as Slot } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { _ as ChevronLeft, a as Plus, b as BookOpen, c as Music, d as Heart, f as Footprints, g as ChevronRight, h as Coffee, i as Sun, l as Moon, m as Droplets, o as Pencil, p as Dumbbell, r as Trash2, s as PenLine, t as X, u as Leaf, v as Check, y as Brain } from "../_libs/lucide-react.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as cn, i as TooltipTrigger, n as Tooltip, r as TooltipContent } from "./router-CshaZdIY.mjs";
import { a as startOfMonth, c as startOfDay, i as format, l as startOfWeek, n as subDays, o as eachDayOfInterval, r as isSameMonth, s as endOfMonth, t as es, u as addDays } from "../_libs/date-fns.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-6SPfcuvw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[color,background-color,box-shadow,transform,opacity] duration-quick ease-smooth-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90",
			secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
			outline: "border border-border bg-card text-foreground hover:bg-secondary shadow-border",
			ghost: "text-foreground hover:bg-secondary",
			destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 rounded-sm px-3",
			lg: "h-12 px-5",
			icon: "size-11",
			"icon-sm": "size-9 rounded-sm"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = (0, import_react.forwardRef)(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
function AppHeader({ mode, onModeChange, onCreate }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex size-10 items-center justify-center rounded-md bg-primary text-primary-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 24 24",
					className: "size-5",
					fill: "none",
					"aria-hidden": "true",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M6 12.5l4 4 8-8.5",
						stroke: "currentColor",
						strokeWidth: "2.2",
						strokeLinecap: "round",
						strokeLinejoin: "round"
					})
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl leading-none font-medium tracking-tight",
				children: "Racha"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Hábitos, marcas y constancia"
			})] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 rounded-md bg-secondary p-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onModeChange("week"),
					className: cn("h-9 min-w-20 rounded-sm px-3 text-sm font-medium transition-[background-color,color,box-shadow] duration-quick ease-smooth-out", mode === "week" ? "bg-card text-foreground shadow-border" : "text-muted-foreground hover:text-foreground"),
					children: "Semana"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onModeChange("month"),
					className: cn("h-9 min-w-20 rounded-sm px-3 text-sm font-medium transition-[background-color,color,box-shadow] duration-quick ease-smooth-out", mode === "month" ? "bg-card text-foreground shadow-border" : "text-muted-foreground hover:text-foreground"),
					children: "Mes"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: onCreate,
				className: "ml-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden sm:inline",
						children: "Nuevo hábito"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sm:hidden",
						children: "Nuevo"
					})
				]
			})]
		})]
	});
}
function AppSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl leading-none font-medium tracking-tight",
				children: "Racha"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Hábitos, marcas y constancia"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-11 w-28 rounded-md bg-secondary" })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-5 lg:grid-cols-[minmax(0,20rem)_minmax(0,1fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-80 rounded-2xl bg-card shadow-border" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-col gap-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-48 rounded-2xl bg-card shadow-border" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-64 rounded-2xl bg-card shadow-border" })]
			})]
		})]
	});
}
function EmptyState({ onCreate }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex flex-col items-center rounded-2xl bg-card px-6 py-14 text-center shadow-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mb-6 size-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-0 rounded-full border border-border" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-2 rounded-full border border-border" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-4 rounded-full bg-primary" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-medium tracking-tight",
				children: "Empieza una racha"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-sm text-sm leading-relaxed text-muted-foreground",
				children: "Crea un hábito, márcalo cada día y observa cómo crece la constancia en el calendario."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "mt-6",
				onClick: onCreate,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Nuevo hábito"]
			})
		]
	});
}
var AlertDialog = Root2;
var AlertDialogPortal = Portal2;
var AlertDialogOverlay = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay2, {
	ref,
	className: cn("fixed inset-0 z-50 bg-overlay data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
AlertDialogOverlay.displayName = Overlay2.displayName;
var AlertDialogContent = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: cn("fixed top-1/2 left-1/2 z-50 grid w-[calc(100%-2rem)] max-w-md -translate-x-1/2 -translate-y-1/2 gap-4 rounded-xl bg-card p-5 text-card-foreground shadow-overlay duration-fast data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
	...props
})] }));
AlertDialogContent.displayName = Content2.displayName;
function AlertDialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1.5 text-left", className),
		...props
	});
}
function AlertDialogFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
		...props
	});
}
var AlertDialogTitle = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title2, {
	ref,
	className: cn("font-display text-xl font-medium tracking-tight", className),
	...props
}));
AlertDialogTitle.displayName = Title2.displayName;
var AlertDialogDescription = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Description2, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
AlertDialogDescription.displayName = Description2.displayName;
var AlertDialogAction = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
	ref,
	className: cn(buttonVariants(), className),
	...props
}));
AlertDialogAction.displayName = Action.displayName;
var AlertDialogCancel = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cancel, {
	ref,
	className: cn(buttonVariants({ variant: "outline" }), className),
	...props
}));
AlertDialogCancel.displayName = Cancel.displayName;
var Sheet = Dialog$1;
var SheetPortal = DialogPortal$1;
var SheetOverlay = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-overlay data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
SheetOverlay.displayName = DialogOverlay$1.displayName;
var SheetContent = (0, import_react.forwardRef)(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed inset-x-0 bottom-0 z-50 flex max-h-[92dvh] flex-col rounded-t-2xl bg-card p-5 text-card-foreground shadow-overlay duration-slow data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom sm:inset-y-0 sm:right-0 sm:left-auto sm:h-full sm:max-h-none sm:w-full sm:max-w-md sm:rounded-none sm:rounded-l-2xl sm:data-[state=closed]:slide-out-to-right sm:data-[state=open]:slide-in-from-right", className),
	...props,
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-3 h-1 w-10 rounded-full bg-border sm:hidden" }),
		children,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			className: "absolute top-4 right-4 flex size-9 items-center justify-center rounded-sm text-muted-foreground transition-colors duration-quick hover:bg-secondary hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Cerrar"
			})]
		})
	]
})] }));
SheetContent.displayName = DialogContent$1.displayName;
function SheetHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1.5 pr-10 text-left", className),
		...props
	});
}
var SheetTitle = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("font-display text-xl font-medium tracking-tight", className),
	...props
}));
SheetTitle.displayName = DialogTitle$1.displayName;
var SheetDescription = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
SheetDescription.displayName = DialogDescription$1.displayName;
function toDateKey(date) {
	return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
function todayKey(now = /* @__PURE__ */ new Date()) {
	return toDateKey(startOfDay(now));
}
function isFutureKey(key, now = /* @__PURE__ */ new Date()) {
	return key > todayKey(now);
}
function weekDays(anchor = /* @__PURE__ */ new Date()) {
	const end = startOfDay(anchor);
	return Array.from({ length: 7 }, (_, i) => subDays(end, 6 - i));
}
function monthDays(anchor = /* @__PURE__ */ new Date()) {
	const start = startOfMonth(startOfDay(anchor));
	const end = endOfMonth(start);
	return eachDayOfInterval({
		start,
		end
	});
}
function monthGrid(anchor = /* @__PURE__ */ new Date()) {
	const start = startOfWeek(startOfMonth(startOfDay(anchor)), { weekStartsOn: 1 });
	const end = endOfMonth(startOfDay(anchor));
	const last = startOfWeek(end, { weekStartsOn: 1 });
	const gridEnd = addDays(last, 6);
	return eachDayOfInterval({
		start,
		end: gridEnd
	});
}
function heatmapDays(weeks = 16, anchor = /* @__PURE__ */ new Date()) {
	const end = startOfDay(anchor);
	const endWeek = addDays(startOfWeek(end, { weekStartsOn: 1 }), 6);
	const start = subDays(startOfWeek(end, { weekStartsOn: 1 }), (weeks - 1) * 7);
	return eachDayOfInterval({
		start,
		end: endWeek
	});
}
function dayNumber(date) {
	return format(date, "d", { locale: es });
}
function sentenceCase(value) {
	if (!value) return value;
	return value.charAt(0).toUpperCase() + value.slice(1);
}
function prettyDate(date) {
	return sentenceCase(format(date, "EEEE d 'de' MMMM", { locale: es }));
}
function prettyMonth(date) {
	return sentenceCase(format(date, "LLLL yyyy", { locale: es }));
}
function shortPrettyDate(date) {
	return format(date, "d MMM", { locale: es });
}
var WEEKDAY_HEADERS = [
	"L",
	"M",
	"X",
	"J",
	"V",
	"S",
	"D"
];
var HABIT_COLOR_CLASS = {
	forest: {
		bg: "bg-habit-forest",
		text: "text-habit-forest",
		ring: "ring-habit-forest",
		fill: "fill-habit-forest"
	},
	clay: {
		bg: "bg-habit-clay",
		text: "text-habit-clay",
		ring: "ring-habit-clay",
		fill: "fill-habit-clay"
	},
	slate: {
		bg: "bg-habit-slate",
		text: "text-habit-slate",
		ring: "ring-habit-slate",
		fill: "fill-habit-slate"
	},
	ochre: {
		bg: "bg-habit-ochre",
		text: "text-habit-ochre",
		ring: "ring-habit-ochre",
		fill: "fill-habit-ochre"
	},
	rose: {
		bg: "bg-habit-rose",
		text: "text-habit-rose",
		ring: "ring-habit-rose",
		fill: "fill-habit-rose"
	},
	teal: {
		bg: "bg-habit-teal",
		text: "text-habit-teal",
		ring: "ring-habit-teal",
		fill: "fill-habit-teal"
	},
	ink: {
		bg: "bg-habit-ink",
		text: "text-habit-ink",
		ring: "ring-habit-ink",
		fill: "fill-habit-ink"
	},
	olive: {
		bg: "bg-habit-olive",
		text: "text-habit-olive",
		ring: "ring-habit-olive",
		fill: "fill-habit-olive"
	}
};
var HABIT_ICONS = {
	droplets: Droplets,
	book: BookOpen,
	walk: Footprints,
	brain: Brain,
	moon: Moon,
	dumbbell: Dumbbell,
	sun: Sun,
	heart: Heart,
	coffee: Coffee,
	pen: PenLine,
	music: Music,
	leaf: Leaf
};
var HABIT_ICON_LABELS = {
	droplets: "Agua",
	book: "Lectura",
	walk: "Caminar",
	brain: "Mente",
	moon: "Descanso",
	dumbbell: "Fuerza",
	sun: "Mañana",
	heart: "Cuidado",
	coffee: "Ritual",
	pen: "Escribir",
	music: "Música",
	leaf: "Naturaleza"
};
function HabitHeatmap({ habit, dates, weeks = 16 }) {
	const days = heatmapDays(weeks);
	const today = todayKey();
	const columns = [];
	for (let i = 0; i < days.length; i += 7) columns.push(days.slice(i, i + 7));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm font-medium",
				children: [
					"Últimas ",
					weeks,
					" semanas"
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Lunes arriba"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex gap-1 overflow-x-auto pb-1",
			children: columns.map((week, weekIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-1",
				children: week.map((date) => {
					const key = toDateKey(date);
					const checked = dates.has(key);
					const future = key > today;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("size-3 rounded-xs sm:size-3.5", future ? "bg-secondary/60" : checked ? HABIT_COLOR_CLASS[habit.color].bg : "bg-secondary") })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TooltipContent, { children: [shortPrettyDate(date), future ? "" : checked ? " · hecho" : " · pendiente"] })] }, key);
				})
			}, weekIndex))
		})]
	});
}
function checkSet(checks, habitId) {
	return new Set(checks[habitId] ?? []);
}
function isChecked(checks, habitId, dateKey) {
	return (checks[habitId] ?? []).includes(dateKey);
}
function currentStreak(dates, now = /* @__PURE__ */ new Date()) {
	const set = dates instanceof Set ? dates : new Set(dates);
	const today = startOfDay(now);
	const todayK = toDateKey(today);
	let cursor = set.has(todayK) ? today : subDays(today, 1);
	let streak = 0;
	while (set.has(toDateKey(cursor))) {
		streak += 1;
		cursor = subDays(cursor, 1);
	}
	return streak;
}
function longestStreak(dates) {
	const sorted = [...dates].sort();
	if (sorted.length === 0) return 0;
	let best = 1;
	let run = 1;
	for (let i = 1; i < sorted.length; i += 1) {
		const prev = sorted[i - 1];
		const cur = sorted[i];
		const prevDate = new Date(Number(prev.slice(0, 4)), Number(prev.slice(5, 7)) - 1, Number(prev.slice(8, 10)));
		if (cur === toDateKey(addDays(prevDate, 1))) {
			run += 1;
			best = Math.max(best, run);
		} else if (cur !== prev) run = 1;
	}
	return best;
}
function completionsInRange(dates, start, end) {
	let count = 0;
	const startK = toDateKey(startOfDay(start));
	const endK = toDateKey(startOfDay(end));
	for (const key of dates) if (key >= startK && key <= endK) count += 1;
	return count;
}
function expectedDays(createdAt, start, end) {
	const created = startOfDay(new Date(createdAt));
	const from = startOfDay(start) < created ? created : startOfDay(start);
	const to = startOfDay(end);
	if (to < from) return 0;
	return Math.round((to.getTime() - from.getTime()) / 864e5) + 1;
}
function completionRate(dates, createdAt, start, end) {
	const total = expectedDays(createdAt, start, end);
	if (total <= 0) return 0;
	return completionsInRange(dates, start, end) / total;
}
function dayCompletion(habits, checks, dateKey) {
	const active = habits.filter((habit) => {
		return toDateKey(startOfDay(new Date(habit.createdAt))) <= dateKey;
	});
	return {
		done: active.filter((habit) => (checks[habit.id] ?? []).includes(dateKey)).length,
		total: active.length
	};
}
function habitStats(habit, checks, now = /* @__PURE__ */ new Date()) {
	const dates = checkSet(checks, habit.id);
	const today = startOfDay(now);
	return {
		current: currentStreak(dates, today),
		longest: longestStreak(dates),
		rate30: completionRate(dates, habit.createdAt, subDays(today, 29), today),
		rate7: completionRate(dates, habit.createdAt, subDays(today, 6), today),
		total: dates.size
	};
}
var SEED_CREATED = "2026-06-01T08:00:00.000Z";
var SEED_HABITS = [
	{
		id: "h-agua",
		name: "Beber agua",
		color: "teal",
		icon: "droplets",
		createdAt: SEED_CREATED
	},
	{
		id: "h-leer",
		name: "Leer 20 min",
		color: "clay",
		icon: "book",
		createdAt: SEED_CREATED
	},
	{
		id: "h-caminar",
		name: "Caminar",
		color: "forest",
		icon: "walk",
		createdAt: SEED_CREATED
	},
	{
		id: "h-meditar",
		name: "Meditar",
		color: "slate",
		icon: "brain",
		createdAt: SEED_CREATED
	},
	{
		id: "h-dormir",
		name: "Dormir a las 23",
		color: "rose",
		icon: "moon",
		createdAt: SEED_CREATED
	}
];
function daysAgoKeys(today, predicate, span = 70) {
	const keys = [];
	for (let i = span; i >= 0; i -= 1) if (predicate(i)) keys.push(toDateKey(subDays(today, i)));
	return keys;
}
function createSeed(now = /* @__PURE__ */ new Date()) {
	const today = startOfDay(now);
	return {
		hasOnboarded: true,
		habits: SEED_HABITS,
		checks: {
			"h-agua": daysAgoKeys(today, (i) => i <= 6 || i % 5 !== 0),
			"h-leer": daysAgoKeys(today, (i) => i <= 13 || i % 7 !== 3 && i % 6 !== 0),
			"h-caminar": daysAgoKeys(today, (i) => i <= 3 || i % 3 !== 0 && i % 8 !== 1),
			"h-meditar": daysAgoKeys(today, (i) => i !== 0 && i !== 1 && i % 2 === 0 && i % 9 !== 0),
			"h-dormir": daysAgoKeys(today, (i) => i === 1 || i === 2 || i > 2 && i % 4 !== 0)
		}
	};
}
var emptySnapshot = {
	habits: [],
	checks: {},
	hasOnboarded: false
};
var useHabitsStore = create()(persist((set, get) => ({
	...emptySnapshot,
	hydrated: false,
	setHydrated: (value) => set({ hydrated: value }),
	addHabit: ({ name, color, icon }) => {
		const id = typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : `h-${Date.now()}`;
		const habit = {
			id,
			name: name.trim(),
			color,
			icon,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		set((state) => ({
			habits: [...state.habits, habit],
			hasOnboarded: true
		}));
		return id;
	},
	updateHabit: (id, patch) => {
		set((state) => ({ habits: state.habits.map((habit) => habit.id === id ? {
			...habit,
			...patch,
			name: patch.name !== void 0 ? patch.name.trim() : habit.name
		} : habit) }));
	},
	deleteHabit: (id) => {
		set((state) => {
			const { [id]: _removed, ...rest } = state.checks;
			return {
				habits: state.habits.filter((habit) => habit.id !== id),
				checks: rest
			};
		});
	},
	toggleCheck: (habitId, dateKey) => {
		if (isFutureKey(dateKey)) return;
		const habit = get().habits.find((item) => item.id === habitId);
		if (!habit) return;
		if (dateKey < toDateKey(new Date(habit.createdAt))) return;
		set((state) => {
			const current = state.checks[habitId] ?? [];
			const has = current.includes(dateKey);
			return { checks: {
				...state.checks,
				[habitId]: has ? current.filter((key) => key !== dateKey) : [...current, dateKey]
			} };
		});
	}
}), {
	name: "racha-habits-v1",
	storage: createJSONStorage(() => localStorage),
	partialize: (state) => ({
		habits: state.habits,
		checks: state.checks,
		hasOnboarded: state.hasOnboarded
	}),
	skipHydration: true
}));
var hydrationPromise = null;
function hydrateHabitsStore() {
	if (hydrationPromise) return hydrationPromise;
	hydrationPromise = (async () => {
		await useHabitsStore.persist.rehydrate();
		if (!useHabitsStore.getState().hasOnboarded) useHabitsStore.setState({
			...createSeed(),
			hydrated: true
		});
		else useHabitsStore.setState({ hydrated: true });
	})();
	return hydrationPromise;
}
function percentLabel$1(value) {
	return `${Math.round(value * 100)}%`;
}
function HabitDetailSheet({ habit, onClose, onEdit }) {
	const checks = useHabitsStore((s) => s.checks);
	const deleteHabit = useHabitsStore((s) => s.deleteHabit);
	const [confirmOpen, setConfirmOpen] = (0, import_react.useState)(false);
	const dates = habit ? checkSet(checks, habit.id) : /* @__PURE__ */ new Set();
	const stats = habit ? habitStats(habit, checks) : null;
	const Icon = habit ? HABIT_ICONS[habit.icon] : null;
	function handleDelete() {
		if (!habit) return;
		deleteHabit(habit.id);
		setConfirmOpen(false);
		onClose();
		toast("Hábito eliminado");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open: Boolean(habit),
		onOpenChange: (open) => {
			if (!open) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetContent, { children: habit && stats && Icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-0 flex-1 flex-col overflow-y-auto pr-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("flex size-11 items-center justify-center rounded-md text-habit-on", HABIT_COLOR_CLASS[habit.color].bg),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: habit.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetDescription, { children: "Racha actual y completitud de los últimos 30 días." })]
					})]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 rounded-xl bg-background p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-muted-foreground",
						children: "Racha actual"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display mt-1 text-4xl font-medium tracking-tight tabular-nums",
						children: [stats.current, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2 text-lg text-muted-foreground",
							children: stats.current === 1 ? "día" : "días"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-4 grid grid-cols-2 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
							label: "Récord",
							value: `${stats.longest}`,
							hint: "días seguidos"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
							label: "Últimos 30 días",
							value: percentLabel$1(stats.rate30),
							hint: "completitud"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
							label: "Esta semana",
							value: percentLabel$1(stats.rate7),
							hint: "completitud"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
							label: "Total",
							value: `${stats.total}`,
							hint: "días marcados"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HabitHeatmap, {
						habit,
						dates
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-col gap-2 pb-4 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						className: "flex-1",
						onClick: () => onEdit(habit),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {}), "Editar"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "destructive",
						className: "flex-1",
						onClick: () => setConfirmOpen(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), "Eliminar"]
					})]
				})
			]
		}) : null })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
		open: confirmOpen,
		onOpenChange: setConfirmOpen,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "Eliminar hábito" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogDescription, { children: [
			"Se borrará «",
			habit?.name,
			"» y todo su historial de marcas. Esta acción no se puede deshacer."
		] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "Cancelar" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
			className: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
			onClick: handleDelete,
			children: "Eliminar"
		})] })] })
	})] });
}
function StatCard({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-background px-3 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
				className: "text-xs font-medium text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
				className: "font-display mt-1 text-2xl font-medium tracking-tight tabular-nums",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: hint
			})
		]
	});
}
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-overlay data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = (0, import_react.forwardRef)(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed top-1/2 left-1/2 z-50 grid w-[calc(100%-2rem)] max-w-md -translate-x-1/2 -translate-y-1/2 gap-4 rounded-xl bg-card p-5 text-card-foreground shadow-overlay duration-fast data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute top-3 right-3 flex size-9 items-center justify-center rounded-sm text-muted-foreground transition-colors duration-quick hover:bg-secondary hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Cerrar"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1.5 pr-8 text-left", className),
		...props
	});
}
function DialogFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
		...props
	});
}
var DialogTitle = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("font-display text-xl font-medium tracking-tight", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
var HABIT_COLOR_IDS = [
	"forest",
	"clay",
	"slate",
	"ochre",
	"rose",
	"teal",
	"ink",
	"olive"
];
var HABIT_ICON_IDS = [
	"droplets",
	"book",
	"walk",
	"brain",
	"moon",
	"dumbbell",
	"sun",
	"heart",
	"coffee",
	"pen",
	"music",
	"leaf"
];
var Input = (0, import_react.forwardRef)(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-11 w-full rounded-md border border-input bg-card px-3 text-base text-foreground shadow-border transition-[box-shadow,border-color] duration-quick ease-smooth-out placeholder:text-muted-foreground focus-visible:border-ring focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/30 disabled:cursor-not-allowed disabled:opacity-50", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var Label = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn("text-sm font-medium leading-none text-foreground peer-disabled:cursor-not-allowed peer-disabled:opacity-50", className),
	...props
}));
Label.displayName = Root.displayName;
function HabitFormFields({ value, onChange, autoFocus }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "habit-name",
					children: "Nombre"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "habit-name",
					value: value.name,
					autoFocus,
					placeholder: "Ej. Leer 20 minutos",
					maxLength: 40,
					onChange: (event) => onChange({
						...value,
						name: event.target.value
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Color" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: HABIT_COLOR_IDS.map((color) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": color,
						"aria-pressed": value.color === color,
						onClick: () => onChange({
							...value,
							color
						}),
						className: cn("size-9 rounded-full transition-[transform,box-shadow] duration-quick ease-smooth-out", HABIT_COLOR_CLASS[color].bg, value.color === color ? "ring-2 ring-ring ring-offset-2 ring-offset-card" : "opacity-80 hover:opacity-100")
					}, color))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Icono" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-6 gap-2",
					children: HABIT_ICON_IDS.map((icon) => {
						const Icon = HABIT_ICONS[icon];
						const selected = value.icon === icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": HABIT_ICON_LABELS[icon],
							"aria-pressed": selected,
							onClick: () => onChange({
								...value,
								icon
							}),
							className: cn("flex size-11 items-center justify-center rounded-md border transition-[background-color,border-color] duration-quick ease-smooth-out", selected ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-foreground hover:bg-secondary"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
						}, icon);
					})
				})]
			})
		]
	});
}
var DEFAULT_DRAFT = {
	name: "",
	color: "forest",
	icon: "leaf"
};
function HabitFormDialog({ open, habit, onOpenChange }) {
	const addHabit = useHabitsStore((s) => s.addHabit);
	const updateHabit = useHabitsStore((s) => s.updateHabit);
	const [draft, setDraft] = (0, import_react.useState)(DEFAULT_DRAFT);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setDraft(habit ? {
			name: habit.name,
			color: habit.color,
			icon: habit.icon
		} : DEFAULT_DRAFT);
	}, [open, habit]);
	const isEdit = Boolean(habit);
	const canSave = draft.name.trim().length > 0;
	function handleSave() {
		if (!canSave) return;
		if (habit) {
			updateHabit(habit.id, draft);
			toast("Hábito actualizado");
		} else {
			addHabit(draft);
			toast("Hábito creado");
		}
		onOpenChange(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: isEdit ? "Editar hábito" : "Nuevo hábito" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: isEdit ? "Cambia el nombre, el color o el icono. El historial se conserva." : "Elige un nombre claro y un color para reconocerlo de un vistazo." })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HabitFormFields, {
				value: draft,
				onChange: setDraft,
				autoFocus: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => onOpenChange(false),
				children: "Cancelar"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: handleSave,
				disabled: !canSave,
				children: isEdit ? "Guardar" : "Crear hábito"
			})] })
		] })
	});
}
function CheckCell({ checked, color, label, isToday = false, disabled = false, size = "md", onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		"aria-pressed": checked,
		disabled,
		"data-checked": checked,
		onClick: onToggle,
		className: cn("check-pop relative flex shrink-0 items-center justify-center rounded-sm border transition-[background-color,border-color,box-shadow,transform] duration-quick ease-smooth-out", size === "md" ? "size-9 sm:size-10" : "size-7", checked ? cn(HABIT_COLOR_CLASS[color].bg, "border-transparent text-habit-on") : "border-border bg-card text-transparent hover:border-foreground/25", isToday && !checked && "ring-2 ring-ring/25 ring-offset-1 ring-offset-background", disabled && "cursor-not-allowed opacity-30 hover:border-border"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
			className: size === "md" ? "size-3.5" : "size-3",
			strokeWidth: 2.75
		})
	});
}
function percentLabel(value) {
	return `${Math.round(value * 100)}%`;
}
function HabitGrid({ mode, month, onOpenHabit }) {
	const habits = useHabitsStore((s) => s.habits);
	const checks = useHabitsStore((s) => s.checks);
	const toggleCheck = useHabitsStore((s) => s.toggleCheck);
	const scroller = (0, import_react.useRef)(null);
	const today = todayKey();
	const days = mode === "week" ? weekDays() : monthDays(month);
	const cell = mode === "week" ? "md" : "sm";
	(0, import_react.useEffect)(() => {
		const root = scroller.current;
		if (!root) return;
		const todayEl = root.querySelector("[data-today-col='true']");
		if (todayEl) todayEl.scrollIntoView({
			inline: "center",
			block: "nearest",
			behavior: "smooth"
		});
	}, [
		mode,
		month,
		habits.length
	]);
	if (habits.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "min-w-0 overflow-hidden rounded-2xl bg-card shadow-border",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-4 sm:px-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg font-medium tracking-tight",
				children: "Marcas diarias"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Toca una celda para marcar o deshacer el día."
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: scroller,
			className: "mt-3 overflow-x-auto pb-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-max px-4 sm:px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sticky left-0 z-10 w-36 shrink-0 bg-card pr-2 text-xs font-medium text-muted-foreground sm:w-40",
						children: "Hábito"
					}), days.map((date) => {
						const key = toDateKey(date);
						const isToday = key === today;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							"data-today-col": isToday ? "true" : void 0,
							className: cn("flex shrink-0 flex-col items-center text-xs tabular-nums", mode === "week" ? "w-9 sm:w-10" : "w-7", isToday ? "font-medium text-foreground" : "text-muted-foreground"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "uppercase",
								children: WEEKDAY_HEADERS[date.getDay() === 0 ? 6 : date.getDay() - 1]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: dayNumber(date) })]
						}, key);
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 flex flex-col gap-1.5",
					children: habits.map((habit) => {
						const stats = habitStats(habit, checks);
						const Icon = HABIT_ICONS[habit.icon];
						const createdKey = toDateKey(new Date(habit.createdAt));
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onOpenHabit(habit),
								className: "sticky left-0 z-10 flex h-11 w-36 shrink-0 items-center gap-2 bg-card pr-2 text-left sm:w-40",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("flex size-8 shrink-0 items-center justify-center rounded-sm text-habit-on", HABIT_COLOR_CLASS[habit.color].bg),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3.5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-sm font-medium",
										children: habit.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block text-xs tabular-nums text-muted-foreground",
										children: [
											stats.current,
											" · ",
											percentLabel(stats.rate30)
										]
									})]
								})]
							}), days.map((date) => {
								const key = toDateKey(date);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: cn("flex shrink-0 justify-center", mode === "week" ? "w-9 sm:w-10" : "w-7"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckCell, {
										checked: isChecked(checks, habit.id, key),
										color: habit.color,
										isToday: key === today,
										disabled: isFutureKey(key) || key < createdKey,
										size: cell,
										label: `${habit.name}, ${key}`,
										onToggle: () => toggleCheck(habit.id, key)
									})
								}, key);
							})]
						}, habit.id);
					})
				})]
			})
		})]
	});
}
function intensityClass(done, total) {
	if (total === 0 || done === 0) return "bg-secondary text-muted-foreground";
	const ratio = done / total;
	if (ratio >= 1) return "bg-primary text-primary-foreground";
	if (ratio >= .67) return "bg-primary/70 text-primary-foreground";
	if (ratio >= .34) return "bg-primary/45 text-foreground";
	return "bg-primary/20 text-foreground";
}
function StreakCalendar({ mode, month, onMonthChange }) {
	const habits = useHabitsStore((s) => s.habits);
	const checks = useHabitsStore((s) => s.checks);
	const now = startOfDay(/* @__PURE__ */ new Date());
	const today = todayKey(now);
	const days = mode === "week" ? weekDays(now) : monthGrid(month);
	const canNext = startOfMonth(month) < startOfMonth(now);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "min-w-0 overflow-hidden rounded-2xl bg-card p-4 shadow-border sm:p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg font-medium tracking-tight",
					children: "Calendario de rachas"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: mode === "week" ? "Completitud de los últimos 7 días" : "Completitud diaria del mes"
				})]
			}), mode === "month" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex shrink-0 items-center gap-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "icon-sm",
						"aria-label": "Mes anterior",
						onClick: () => onMonthChange(new Date(month.getFullYear(), month.getMonth() - 1, 1)),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "min-w-28 text-center text-sm font-medium tabular-nums",
						children: prettyMonth(month)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "icon-sm",
						"aria-label": "Mes siguiente",
						disabled: !canNext,
						onClick: () => onMonthChange(new Date(month.getFullYear(), month.getMonth() + 1, 1)),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {})
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "shrink-0 text-sm font-medium text-muted-foreground",
				children: "7 días"
			})]
		}), mode === "week" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-7 gap-1.5",
			children: days.map((date) => {
				const key = toDateKey(date);
				const { done, total } = dayCompletion(habits, checks, key);
				const isToday = key === today;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("flex min-h-16 flex-col items-center justify-center rounded-md px-1 py-2", intensityClass(done, total), isToday && "ring-2 ring-ring ring-offset-2 ring-offset-card"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium uppercase",
								children: WEEKDAY_HEADERS[date.getDay() === 0 ? 6 : date.getDay() - 1]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display mt-1 text-lg leading-none tabular-nums",
								children: dayNumber(date)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 text-xs tabular-nums opacity-80",
								children: total === 0 ? "—" : `${done}/${total}`
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TooltipContent, { children: [
					shortPrettyDate(date),
					": ",
					done,
					" de ",
					total,
					" hábitos"
				] })] }, key);
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-2 grid grid-cols-7 gap-1",
					children: WEEKDAY_HEADERS.map((label) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-center text-xs font-medium text-muted-foreground",
						children: label
					}, label))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-7 gap-1",
					children: days.map((date) => {
						const key = toDateKey(date);
						const inMonth = isSameMonth(date, month);
						const { done, total } = dayCompletion(habits, checks, key);
						const isToday = key === today;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: cn("flex aspect-square items-center justify-center rounded-sm text-xs font-medium tabular-nums", !inMonth && "opacity-30", key > today ? "bg-secondary/50 text-muted-foreground" : intensityClass(done, total), isToday && "ring-2 ring-ring ring-offset-1 ring-offset-card"),
								children: dayNumber(date)
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, { children: inMonth ? `${shortPrettyDate(date)}: ${done} de ${total} hábitos` : shortPrettyDate(date) })] }, key);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex items-center justify-end gap-1.5 text-xs text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Menos" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-3 rounded-xs bg-secondary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-3 rounded-xs bg-primary/20" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-3 rounded-xs bg-primary/45" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-3 rounded-xs bg-primary/70" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-3 rounded-xs bg-primary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Más" })
					]
				})
			]
		})]
	});
}
function ProgressRing({ value, size = 96, stroke = 7, className, children }) {
	const radius = (size - stroke) / 2;
	const circumference = 2 * Math.PI * radius;
	const offset = circumference * (1 - Math.min(1, Math.max(0, value)));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative inline-flex items-center justify-center", className),
		style: {
			width: size,
			height: size
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			width: size,
			height: size,
			viewBox: `0 0 ${size} ${size}`,
			className: "-rotate-90",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: size / 2,
				cy: size / 2,
				r: radius,
				fill: "none",
				className: "stroke-secondary",
				strokeWidth: stroke
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: size / 2,
				cy: size / 2,
				r: radius,
				fill: "none",
				className: "stroke-primary transition-[stroke-dashoffset] duration-slow ease-smooth-out",
				strokeWidth: stroke,
				strokeLinecap: "round",
				strokeDasharray: circumference,
				strokeDashoffset: offset
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute inset-0 flex flex-col items-center justify-center",
			children
		})]
	});
}
function greeting(now) {
	const hour = now.getHours();
	if (hour < 12) return "Buenos días";
	if (hour < 19) return "Buenas tardes";
	return "Buenas noches";
}
function progressCopy(done, total) {
	if (total === 0) return "Crea tu primer hábito para empezar la racha.";
	if (done === 0) return "Hoy empieza ahora. Una marca basta.";
	if (done === total) return "Día completo. Así se construye una racha.";
	const left = total - done;
	return left === 1 ? "Te queda uno. Cierra el día." : `Te quedan ${left}. Sigue.`;
}
function TodayPanel({ now = /* @__PURE__ */ new Date(), onOpenHabit }) {
	const habits = useHabitsStore((s) => s.habits);
	const checks = useHabitsStore((s) => s.checks);
	const toggleCheck = useHabitsStore((s) => s.toggleCheck);
	const key = todayKey(now);
	const done = habits.filter((habit) => isChecked(checks, habit.id, key)).length;
	const total = habits.length;
	const ratio = total === 0 ? 0 : done / total;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl bg-card p-5 shadow-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-muted-foreground",
				children: greeting(now)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display mt-1 text-2xl font-medium tracking-tight",
				children: prettyDate(now)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressRing, {
					value: ratio,
					size: 92,
					stroke: 7,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-display text-xl font-medium tabular-nums leading-none",
						children: [done, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted-foreground",
							children: ["/", total || 0]
						})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-52 text-sm leading-relaxed text-muted-foreground",
					children: progressCopy(done, total)
				})]
			}),
			habits.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-5 flex flex-col gap-2",
				children: habits.map((habit) => {
					const checked = isChecked(checks, habit.id, key);
					const Icon = HABIT_ICONS[habit.icon];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 rounded-lg bg-background p-1.5 pr-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => toggleCheck(habit.id, key),
							"aria-pressed": checked,
							"aria-label": `${checked ? "Desmarcar" : "Marcar"} ${habit.name}`,
							"data-checked": checked,
							className: cn("check-pop flex size-11 shrink-0 items-center justify-center rounded-md border transition-[background-color,border-color,transform] duration-quick ease-smooth-out", checked ? cn(HABIT_COLOR_CLASS[habit.color].bg, "border-transparent text-habit-on") : "border-border bg-card text-muted-foreground hover:border-foreground/25"),
							children: checked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
								className: "size-5",
								strokeWidth: 2.5
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onOpenHabit(habit),
							className: "min-w-0 flex-1 rounded-sm px-1 py-2 text-left",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("block truncate text-sm font-medium", checked && "text-muted-foreground line-through"),
								children: habit.name
							})
						})]
					}) }, habit.id);
				})
			}) : null
		]
	});
}
function Home() {
	const hydrated = useHabitsStore((s) => s.hydrated);
	const habits = useHabitsStore((s) => s.habits);
	const [mode, setMode] = (0, import_react.useState)("week");
	const [month, setMonth] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	const [formOpen, setFormOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [detail, setDetail] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		hydrateHabitsStore();
	}, []);
	function openCreate() {
		setEditing(null);
		setFormOpen(true);
	}
	function openEdit(habit) {
		setDetail(null);
		setEditing(habit);
		setFormOpen(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-dvh max-w-5xl overflow-x-hidden px-4 py-6 sm:px-6 sm:py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "stagger-in flex min-w-0 flex-col gap-5",
				children: hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {
					mode,
					onModeChange: setMode,
					onCreate: openCreate
				}), habits.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, { onCreate: openCreate }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid min-w-0 items-start gap-5 lg:grid-cols-[minmax(0,20rem)_minmax(0,1fr)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TodayPanel, { onOpenHabit: setDetail }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 flex-col gap-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StreakCalendar, {
							mode,
							month,
							onMonthChange: setMonth
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HabitGrid, {
							mode,
							month,
							onOpenHabit: setDetail
						})]
					})]
				})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppSkeleton, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HabitFormDialog, {
				open: formOpen,
				habit: editing,
				onOpenChange: (open) => {
					setFormOpen(open);
					if (!open) setEditing(null);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HabitDetailSheet, {
				habit: detail,
				onClose: () => setDetail(null),
				onEdit: openEdit
			})
		]
	});
}
//#endregion
export { Home as component };
