//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D3xKBFUm.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BtR0pUgw.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BtR0pUgw.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Buzj9FQ2.js"]
	}
} });
//#endregion
export { tsrStartManifest };
