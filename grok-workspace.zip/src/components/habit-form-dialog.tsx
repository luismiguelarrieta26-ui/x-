import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { HabitFormFields, type HabitDraft } from "@/components/habit-form-fields";
import { useHabitsStore } from "@/lib/habits/store";
import type { Habit } from "@/lib/habits/types";

const DEFAULT_DRAFT: HabitDraft = {
  name: "",
  color: "forest",
  icon: "leaf",
};

type HabitFormDialogProps = {
  open: boolean;
  habit: Habit | null;
  onOpenChange: (open: boolean) => void;
};

export function HabitFormDialog({
  open,
  habit,
  onOpenChange,
}: HabitFormDialogProps) {
  const addHabit = useHabitsStore((s) => s.addHabit);
  const updateHabit = useHabitsStore((s) => s.updateHabit);
  const [draft, setDraft] = useState<HabitDraft>(DEFAULT_DRAFT);

  useEffect(() => {
    if (!open) return;
    setDraft(
      habit
        ? { name: habit.name, color: habit.color, icon: habit.icon }
        : DEFAULT_DRAFT,
    );
  }, [open, habit]);

  const isEdit = Boolean(habit);
  const canSave = draft.name.trim().length > 0;

  function handleSave() {
    if (!canSave) return;
    if (habit) {
      updateHabit(habit.id, draft);
      toast("Hábito actualizado");
    } else {
      addHabit(draft);
      toast("Hábito creado");
    }
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{isEdit ? "Editar hábito" : "Nuevo hábito"}</DialogTitle>
          <DialogDescription>
            {isEdit
              ? "Cambia el nombre, el color o el icono. El historial se conserva."
              : "Elige un nombre claro y un color para reconocerlo de un vistazo."}
          </DialogDescription>
        </DialogHeader>
        <HabitFormFields value={draft} onChange={setDraft} autoFocus />
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={!canSave}>
            {isEdit ? "Guardar" : "Crear hábito"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
