import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";

type EmptyStateProps = {
  onCreate: () => void;
};

export function EmptyState({ onCreate }: EmptyStateProps) {
  return (
    <section className="flex flex-col items-center rounded-2xl bg-card px-6 py-14 text-center shadow-border">
      <div className="relative mb-6 size-16">
        <span className="absolute inset-0 rounded-full border border-border" />
        <span className="absolute inset-2 rounded-full border border-border" />
        <span className="absolute inset-4 rounded-full bg-primary" />
      </div>
      <h2 className="font-display text-2xl font-medium tracking-tight">
        Empieza una racha
      </h2>
      <p className="mt-2 max-w-sm text-sm leading-relaxed text-muted-foreground">
        Crea un hábito, márcalo cada día y observa cómo crece la constancia en
        el calendario.
      </p>
      <Button className="mt-6" onClick={onCreate}>
        <Plus />
        Nuevo hábito
      </Button>
    </section>
  );
}
