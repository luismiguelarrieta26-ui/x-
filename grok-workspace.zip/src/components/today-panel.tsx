import { Check } from "lucide-react";
import { ProgressRing } from "@/components/progress-ring";
import { HABIT_COLOR_CLASS, HABIT_ICONS } from "@/lib/habits/palette";
import { prettyDate, todayKey } from "@/lib/habits/dates";
import { isChecked } from "@/lib/habits/stats";
import { useHabitsStore } from "@/lib/habits/store";
import type { Habit } from "@/lib/habits/types";
import { cn } from "@/lib/utils";

function greeting(now: Date): string {
  const hour = now.getHours();
  if (hour < 12) return "Buenos días";
  if (hour < 19) return "Buenas tardes";
  return "Buenas noches";
}

function progressCopy(done: number, total: number): string {
  if (total === 0) return "Crea tu primer hábito para empezar la racha.";
  if (done === 0) return "Hoy empieza ahora. Una marca basta.";
  if (done === total) return "Día completo. Así se construye una racha.";
  const left = total - done;
  return left === 1 ? "Te queda uno. Cierra el día." : `Te quedan ${left}. Sigue.`;
}

type TodayPanelProps = {
  now?: Date;
  onOpenHabit: (habit: Habit) => void;
};

export function TodayPanel({ now = new Date(), onOpenHabit }: TodayPanelProps) {
  const habits = useHabitsStore((s) => s.habits);
  const checks = useHabitsStore((s) => s.checks);
  const toggleCheck = useHabitsStore((s) => s.toggleCheck);
  const key = todayKey(now);
  const done = habits.filter((habit) => isChecked(checks, habit.id, key)).length;
  const total = habits.length;
  const ratio = total === 0 ? 0 : done / total;

  return (
    <section className="rounded-2xl bg-card p-5 shadow-border">
      <p className="text-sm font-medium text-muted-foreground">
        {greeting(now)}
      </p>
      <h2 className="font-display mt-1 text-2xl font-medium tracking-tight">
        {prettyDate(now)}
      </h2>

      <div className="mt-5 flex items-center gap-4">
        <ProgressRing value={ratio} size={92} stroke={7}>
          <span className="font-display text-xl font-medium tabular-nums leading-none">
            {done}
            <span className="text-muted-foreground">/{total || 0}</span>
          </span>
        </ProgressRing>
        <p className="max-w-52 text-sm leading-relaxed text-muted-foreground">
          {progressCopy(done, total)}
        </p>
      </div>

      {habits.length > 0 ? (
        <ul className="mt-5 flex flex-col gap-2">
          {habits.map((habit) => {
            const checked = isChecked(checks, habit.id, key);
            const Icon = HABIT_ICONS[habit.icon];
            return (
              <li key={habit.id}>
                <div className="flex items-center gap-2 rounded-lg bg-background p-1.5 pr-2">
                  <button
                    type="button"
                    onClick={() => toggleCheck(habit.id, key)}
                    aria-pressed={checked}
                    aria-label={`${checked ? "Desmarcar" : "Marcar"} ${habit.name}`}
                    data-checked={checked}
                    className={cn(
                      "check-pop flex size-11 shrink-0 items-center justify-center rounded-md border transition-[background-color,border-color,transform] duration-quick ease-smooth-out",
                      checked
                        ? cn(
                            HABIT_COLOR_CLASS[habit.color].bg,
                            "border-transparent text-habit-on",
                          )
                        : "border-border bg-card text-muted-foreground hover:border-foreground/25",
                    )}
                  >
                    {checked ? (
                      <Check className="size-5" strokeWidth={2.5} />
                    ) : (
                      <Icon className="size-5" />
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => onOpenHabit(habit)}
                    className="min-w-0 flex-1 rounded-sm px-1 py-2 text-left"
                  >
                    <span
                      className={cn(
                        "block truncate text-sm font-medium",
                        checked && "text-muted-foreground line-through",
                      )}
                    >
                      {habit.name}
                    </span>
                  </button>
                </div>
              </li>
            );
          })}
        </ul>
      ) : null}
    </section>
  );
}
