import { HABIT_COLOR_IDS, HABIT_ICON_IDS } from "@/lib/habits/types";
import type { HabitColorId, HabitIconId } from "@/lib/habits/types";
import { HABIT_COLOR_CLASS, HABIT_ICON_LABELS, HABIT_ICONS } from "@/lib/habits/palette";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

export type HabitDraft = {
  name: string;
  color: HabitColorId;
  icon: HabitIconId;
};

type HabitFormFieldsProps = {
  value: HabitDraft;
  onChange: (next: HabitDraft) => void;
  autoFocus?: boolean;
};

export function HabitFormFields({
  value,
  onChange,
  autoFocus,
}: HabitFormFieldsProps) {
  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-col gap-2">
        <Label htmlFor="habit-name">Nombre</Label>
        <Input
          id="habit-name"
          value={value.name}
          autoFocus={autoFocus}
          placeholder="Ej. Leer 20 minutos"
          maxLength={40}
          onChange={(event) =>
            onChange({ ...value, name: event.target.value })
          }
        />
      </div>

      <div className="flex flex-col gap-2">
        <Label>Color</Label>
        <div className="flex flex-wrap gap-2">
          {HABIT_COLOR_IDS.map((color) => (
            <button
              key={color}
              type="button"
              aria-label={color}
              aria-pressed={value.color === color}
              onClick={() => onChange({ ...value, color })}
              className={cn(
                "size-9 rounded-full transition-[transform,box-shadow] duration-quick ease-smooth-out",
                HABIT_COLOR_CLASS[color].bg,
                value.color === color
                  ? "ring-2 ring-ring ring-offset-2 ring-offset-card"
                  : "opacity-80 hover:opacity-100",
              )}
            />
          ))}
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <Label>Icono</Label>
        <div className="grid grid-cols-6 gap-2">
          {HABIT_ICON_IDS.map((icon) => {
            const Icon = HABIT_ICONS[icon];
            const selected = value.icon === icon;
            return (
              <button
                key={icon}
                type="button"
                aria-label={HABIT_ICON_LABELS[icon]}
                aria-pressed={selected}
                onClick={() => onChange({ ...value, icon })}
                className={cn(
                  "flex size-11 items-center justify-center rounded-md border transition-[background-color,border-color] duration-quick ease-smooth-out",
                  selected
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border bg-card text-foreground hover:bg-secondary",
                )}
              >
                <Icon className="size-4" />
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
