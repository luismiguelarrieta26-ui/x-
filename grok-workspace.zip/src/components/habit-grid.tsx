import { useEffect, useRef } from "react";
import { CheckCell } from "@/components/check-cell";
import { HABIT_COLOR_CLASS, HABIT_ICONS } from "@/lib/habits/palette";
import {
  dayNumber,
  isFutureKey,
  monthDays,
  todayKey,
  toDateKey,
  WEEKDAY_HEADERS,
  weekDays,
} from "@/lib/habits/dates";
import { habitStats, isChecked } from "@/lib/habits/stats";
import { useHabitsStore } from "@/lib/habits/store";
import type { Habit, ViewMode } from "@/lib/habits/types";
import { cn } from "@/lib/utils";

function percentLabel(value: number): string {
  return `${Math.round(value * 100)}%`;
}

type HabitGridProps = {
  mode: ViewMode;
  month: Date;
  onOpenHabit: (habit: Habit) => void;
};

export function HabitGrid({ mode, month, onOpenHabit }: HabitGridProps) {
  const habits = useHabitsStore((s) => s.habits);
  const checks = useHabitsStore((s) => s.checks);
  const toggleCheck = useHabitsStore((s) => s.toggleCheck);
  const scroller = useRef<HTMLDivElement>(null);
  const today = todayKey();
  const days = mode === "week" ? weekDays() : monthDays(month);
  const cell = mode === "week" ? "md" : "sm";

  useEffect(() => {
    const root = scroller.current;
    if (!root) return;
    const todayEl = root.querySelector<HTMLElement>("[data-today-col='true']");
    if (todayEl) {
      todayEl.scrollIntoView({
        inline: "center",
        block: "nearest",
        behavior: "smooth",
      });
    }
  }, [mode, month, habits.length]);

  if (habits.length === 0) return null;

  return (
    <section className="min-w-0 overflow-hidden rounded-2xl bg-card shadow-border">
      <div className="px-4 pt-4 sm:px-5">
        <h2 className="font-display text-lg font-medium tracking-tight">
          Marcas diarias
        </h2>
        <p className="text-sm text-muted-foreground">
          Toca una celda para marcar o deshacer el día.
        </p>
      </div>

      <div ref={scroller} className="mt-3 overflow-x-auto pb-4">
        <div className="min-w-max px-4 sm:px-5">
          <div className="flex items-end gap-1">
            <div className="sticky left-0 z-10 w-36 shrink-0 bg-card pr-2 text-xs font-medium text-muted-foreground sm:w-40">
              Hábito
            </div>
            {days.map((date) => {
              const key = toDateKey(date);
              const isToday = key === today;
              return (
                <div
                  key={key}
                  data-today-col={isToday ? "true" : undefined}
                  className={cn(
                    "flex shrink-0 flex-col items-center text-xs tabular-nums",
                    mode === "week" ? "w-9 sm:w-10" : "w-7",
                    isToday
                      ? "font-medium text-foreground"
                      : "text-muted-foreground",
                  )}
                >
                  <span className="uppercase">
                    {
                      WEEKDAY_HEADERS[
                        date.getDay() === 0 ? 6 : date.getDay() - 1
                      ]
                    }
                  </span>
                  <span>{dayNumber(date)}</span>
                </div>
              );
            })}
          </div>

          <div className="mt-2 flex flex-col gap-1.5">
            {habits.map((habit) => {
              const stats = habitStats(habit, checks);
              const Icon = HABIT_ICONS[habit.icon];
              const createdKey = toDateKey(new Date(habit.createdAt));
              return (
                <div key={habit.id} className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => onOpenHabit(habit)}
                    className="sticky left-0 z-10 flex h-11 w-36 shrink-0 items-center gap-2 bg-card pr-2 text-left sm:w-40"
                  >
                    <span
                      className={cn(
                        "flex size-8 shrink-0 items-center justify-center rounded-sm text-habit-on",
                        HABIT_COLOR_CLASS[habit.color].bg,
                      )}
                    >
                      <Icon className="size-3.5" />
                    </span>
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-medium">
                        {habit.name}
                      </span>
                      <span className="block text-xs tabular-nums text-muted-foreground">
                        {stats.current} · {percentLabel(stats.rate30)}
                      </span>
                    </span>
                  </button>
                  {days.map((date) => {
                    const key = toDateKey(date);
                    return (
                      <div
                        key={key}
                        className={cn(
                          "flex shrink-0 justify-center",
                          mode === "week" ? "w-9 sm:w-10" : "w-7",
                        )}
                      >
                        <CheckCell
                          checked={isChecked(checks, habit.id, key)}
                          color={habit.color}
                          isToday={key === today}
                          disabled={isFutureKey(key) || key < createdKey}
                          size={cell}
                          label={`${habit.name}, ${key}`}
                          onToggle={() => toggleCheck(habit.id, key)}
                        />
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
