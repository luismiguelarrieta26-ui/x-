import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { heatmapDays, shortPrettyDate, todayKey, toDateKey } from "@/lib/habits/dates";
import { HABIT_COLOR_CLASS } from "@/lib/habits/palette";
import type { Habit } from "@/lib/habits/types";
import { cn } from "@/lib/utils";

type HabitHeatmapProps = {
  habit: Habit;
  dates: Set<string>;
  weeks?: number;
};

export function HabitHeatmap({ habit, dates, weeks = 16 }: HabitHeatmapProps) {
  const days = heatmapDays(weeks);
  const today = todayKey();
  const columns: Date[][] = [];
  for (let i = 0; i < days.length; i += 7) {
    columns.push(days.slice(i, i + 7));
  }

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium">Últimas {weeks} semanas</p>
        <p className="text-xs text-muted-foreground">Lunes arriba</p>
      </div>
      <div className="flex gap-1 overflow-x-auto pb-1">
        {columns.map((week, weekIndex) => (
          <div key={weekIndex} className="flex flex-col gap-1">
            {week.map((date) => {
              const key = toDateKey(date);
              const checked = dates.has(key);
              const future = key > today;
              return (
                <Tooltip key={key}>
                  <TooltipTrigger asChild>
                    <div
                      className={cn(
                        "size-3 rounded-xs sm:size-3.5",
                        future
                          ? "bg-secondary/60"
                          : checked
                            ? HABIT_COLOR_CLASS[habit.color].bg
                            : "bg-secondary",
                      )}
                    />
                  </TooltipTrigger>
                  <TooltipContent>
                    {shortPrettyDate(date)}
                    {future ? "" : checked ? " · hecho" : " · pendiente"}
                  </TooltipContent>
                </Tooltip>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}
