import { Check } from "lucide-react";
import { HABIT_COLOR_CLASS } from "@/lib/habits/palette";
import type { HabitColorId } from "@/lib/habits/types";
import { cn } from "@/lib/utils";

type CheckCellProps = {
  checked: boolean;
  color: HabitColorId;
  label: string;
  isToday?: boolean;
  disabled?: boolean;
  size?: "sm" | "md";
  onToggle: () => void;
};

export function CheckCell({
  checked,
  color,
  label,
  isToday = false,
  disabled = false,
  size = "md",
  onToggle,
}: CheckCellProps) {
  return (
    <button
      type="button"
      aria-label={label}
      aria-pressed={checked}
      disabled={disabled}
      data-checked={checked}
      onClick={onToggle}
      className={cn(
        "check-pop relative flex shrink-0 items-center justify-center rounded-sm border transition-[background-color,border-color,box-shadow,transform] duration-quick ease-smooth-out",
        size === "md" ? "size-9 sm:size-10" : "size-7",
        checked
          ? cn(HABIT_COLOR_CLASS[color].bg, "border-transparent text-habit-on")
          : "border-border bg-card text-transparent hover:border-foreground/25",
        isToday && !checked && "ring-2 ring-ring/25 ring-offset-1 ring-offset-background",
        disabled && "cursor-not-allowed opacity-30 hover:border-border",
      )}
    >
      <Check
        className={size === "md" ? "size-3.5" : "size-3"}
        strokeWidth={2.75}
      />
    </button>
  );
}
