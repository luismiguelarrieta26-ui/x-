import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { ViewMode } from "@/lib/habits/types";
import { cn } from "@/lib/utils";

type AppHeaderProps = {
  mode: ViewMode;
  onModeChange: (mode: ViewMode) => void;
  onCreate: () => void;
};

export function AppHeader({ mode, onModeChange, onCreate }: AppHeaderProps) {
  return (
    <header className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex items-center gap-3">
        <span className="flex size-10 items-center justify-center rounded-md bg-primary text-primary-foreground">
          <svg
            viewBox="0 0 24 24"
            className="size-5"
            fill="none"
            aria-hidden="true"
          >
            <path
              d="M6 12.5l4 4 8-8.5"
              stroke="currentColor"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </span>
        <div>
          <p className="font-display text-2xl leading-none font-medium tracking-tight">
            Racha
          </p>
          <p className="mt-1 text-sm text-muted-foreground">
            Hábitos, marcas y constancia
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <div className="grid grid-cols-2 rounded-md bg-secondary p-1">
          <button
            type="button"
            onClick={() => onModeChange("week")}
            className={cn(
              "h-9 min-w-20 rounded-sm px-3 text-sm font-medium transition-[background-color,color,box-shadow] duration-quick ease-smooth-out",
              mode === "week"
                ? "bg-card text-foreground shadow-border"
                : "text-muted-foreground hover:text-foreground",
            )}
          >
            Semana
          </button>
          <button
            type="button"
            onClick={() => onModeChange("month")}
            className={cn(
              "h-9 min-w-20 rounded-sm px-3 text-sm font-medium transition-[background-color,color,box-shadow] duration-quick ease-smooth-out",
              mode === "month"
                ? "bg-card text-foreground shadow-border"
                : "text-muted-foreground hover:text-foreground",
            )}
          >
            Mes
          </button>
        </div>
        <Button onClick={onCreate} className="ml-1">
          <Plus />
          <span className="hidden sm:inline">Nuevo hábito</span>
          <span className="sm:hidden">Nuevo</span>
        </Button>
      </div>
    </header>
  );
}
