export function AppSkeleton() {
  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="font-display text-2xl leading-none font-medium tracking-tight">
            Racha
          </p>
          <p className="mt-1 text-sm text-muted-foreground">
            Hábitos, marcas y constancia
          </p>
        </div>
        <div className="h-11 w-28 rounded-md bg-secondary" />
      </div>
      <div className="grid gap-5 lg:grid-cols-[minmax(0,20rem)_minmax(0,1fr)]">
        <div className="h-80 rounded-2xl bg-card shadow-border" />
        <div className="flex min-w-0 flex-col gap-5">
          <div className="h-48 rounded-2xl bg-card shadow-border" />
          <div className="h-64 rounded-2xl bg-card shadow-border" />
        </div>
      </div>
    </div>
  );
}
