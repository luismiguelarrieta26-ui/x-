import { useState } from "react";
import { Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { HabitHeatmap } from "@/components/habit-heatmap";
import { HABIT_COLOR_CLASS, HABIT_ICONS } from "@/lib/habits/palette";
import { checkSet, habitStats } from "@/lib/habits/stats";
import { useHabitsStore } from "@/lib/habits/store";
import type { Habit } from "@/lib/habits/types";
import { cn } from "@/lib/utils";

function percentLabel(value: number): string {
  return `${Math.round(value * 100)}%`;
}

type HabitDetailSheetProps = {
  habit: Habit | null;
  onClose: () => void;
  onEdit: (habit: Habit) => void;
};

export function HabitDetailSheet({
  habit,
  onClose,
  onEdit,
}: HabitDetailSheetProps) {
  const checks = useHabitsStore((s) => s.checks);
  const deleteHabit = useHabitsStore((s) => s.deleteHabit);
  const [confirmOpen, setConfirmOpen] = useState(false);

  const dates = habit ? checkSet(checks, habit.id) : new Set<string>();
  const stats = habit ? habitStats(habit, checks) : null;
  const Icon = habit ? HABIT_ICONS[habit.icon] : null;

  function handleDelete() {
    if (!habit) return;
    deleteHabit(habit.id);
    setConfirmOpen(false);
    onClose();
    toast("Hábito eliminado");
  }

  return (
    <>
      <Sheet
        open={Boolean(habit)}
        onOpenChange={(open) => {
          if (!open) onClose();
        }}
      >
        <SheetContent>
          {habit && stats && Icon ? (
            <div className="flex min-h-0 flex-1 flex-col overflow-y-auto pr-1">
              <SheetHeader>
                <div className="flex items-center gap-3">
                  <span
                    className={cn(
                      "flex size-11 items-center justify-center rounded-md text-habit-on",
                      HABIT_COLOR_CLASS[habit.color].bg,
                    )}
                  >
                    <Icon className="size-5" />
                  </span>
                  <div className="min-w-0">
                    <SheetTitle>{habit.name}</SheetTitle>
                    <SheetDescription>
                      Racha actual y completitud de los últimos 30 días.
                    </SheetDescription>
                  </div>
                </div>
              </SheetHeader>

              <div className="mt-6 rounded-xl bg-background p-4">
                <p className="text-sm font-medium text-muted-foreground">
                  Racha actual
                </p>
                <p className="font-display mt-1 text-4xl font-medium tracking-tight tabular-nums">
                  {stats.current}
                  <span className="ml-2 text-lg text-muted-foreground">
                    {stats.current === 1 ? "día" : "días"}
                  </span>
                </p>
              </div>

              <dl className="mt-4 grid grid-cols-2 gap-2">
                <StatCard label="Récord" value={`${stats.longest}`} hint="días seguidos" />
                <StatCard
                  label="Últimos 30 días"
                  value={percentLabel(stats.rate30)}
                  hint="completitud"
                />
                <StatCard
                  label="Esta semana"
                  value={percentLabel(stats.rate7)}
                  hint="completitud"
                />
                <StatCard
                  label="Total"
                  value={`${stats.total}`}
                  hint="días marcados"
                />
              </dl>

              <div className="mt-6">
                <HabitHeatmap habit={habit} dates={dates} />
              </div>

              <div className="mt-8 flex flex-col gap-2 pb-4 sm:flex-row">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => onEdit(habit)}
                >
                  <Pencil />
                  Editar
                </Button>
                <Button
                  variant="destructive"
                  className="flex-1"
                  onClick={() => setConfirmOpen(true)}
                >
                  <Trash2 />
                  Eliminar
                </Button>
              </div>
            </div>
          ) : null}
        </SheetContent>
      </Sheet>

      <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Eliminar hábito</AlertDialogTitle>
            <AlertDialogDescription>
              Se borrará «{habit?.name}» y todo su historial de marcas. Esta
              acción no se puede deshacer.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={handleDelete}
            >
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

function StatCard({
  label,
  value,
  hint,
}: {
  label: string;
  value: string;
  hint: string;
}) {
  return (
    <div className="rounded-lg bg-background px-3 py-3">
      <dt className="text-xs font-medium text-muted-foreground">{label}</dt>
      <dd className="font-display mt-1 text-2xl font-medium tracking-tight tabular-nums">
        {value}
      </dd>
      <p className="text-xs text-muted-foreground">{hint}</p>
    </div>
  );
}
