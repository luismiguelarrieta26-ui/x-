import { ChevronLeft, ChevronRight } from "lucide-react";
import { isSameMonth, startOfDay, startOfMonth } from "date-fns";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  dayNumber,
  monthGrid,
  prettyMonth,
  shortPrettyDate,
  todayKey,
  toDateKey,
  WEEKDAY_HEADERS,
  weekDays,
} from "@/lib/habits/dates";
import { dayCompletion } from "@/lib/habits/stats";
import { useHabitsStore } from "@/lib/habits/store";
import type { ViewMode } from "@/lib/habits/types";
import { cn } from "@/lib/utils";

function intensityClass(done: number, total: number): string {
  if (total === 0 || done === 0) return "bg-secondary text-muted-foreground";
  const ratio = done / total;
  if (ratio >= 1) return "bg-primary text-primary-foreground";
  if (ratio >= 0.67) return "bg-primary/70 text-primary-foreground";
  if (ratio >= 0.34) return "bg-primary/45 text-foreground";
  return "bg-primary/20 text-foreground";
}

type StreakCalendarProps = {
  mode: ViewMode;
  month: Date;
  onMonthChange: (next: Date) => void;
};

export function StreakCalendar({
  mode,
  month,
  onMonthChange,
}: StreakCalendarProps) {
  const habits = useHabitsStore((s) => s.habits);
  const checks = useHabitsStore((s) => s.checks);
  const now = startOfDay(new Date());
  const today = todayKey(now);
  const days = mode === "week" ? weekDays(now) : monthGrid(month);
  const canNext = startOfMonth(month) < startOfMonth(now);

  return (
    <section className="min-w-0 overflow-hidden rounded-2xl bg-card p-4 shadow-border sm:p-5">
      <div className="mb-4 flex items-center justify-between gap-3">
        <div className="min-w-0">
          <h2 className="font-display text-lg font-medium tracking-tight">
            Calendario de rachas
          </h2>
          <p className="text-sm text-muted-foreground">
            {mode === "week"
              ? "Completitud de los últimos 7 días"
              : "Completitud diaria del mes"}
          </p>
        </div>
        {mode === "month" ? (
          <div className="flex shrink-0 items-center gap-1">
            <Button
              type="button"
              variant="ghost"
              size="icon-sm"
              aria-label="Mes anterior"
              onClick={() =>
                onMonthChange(
                  new Date(month.getFullYear(), month.getMonth() - 1, 1),
                )
              }
            >
              <ChevronLeft />
            </Button>
            <span className="min-w-28 text-center text-sm font-medium tabular-nums">
              {prettyMonth(month)}
            </span>
            <Button
              type="button"
              variant="ghost"
              size="icon-sm"
              aria-label="Mes siguiente"
              disabled={!canNext}
              onClick={() =>
                onMonthChange(
                  new Date(month.getFullYear(), month.getMonth() + 1, 1),
                )
              }
            >
              <ChevronRight />
            </Button>
          </div>
        ) : (
          <span className="shrink-0 text-sm font-medium text-muted-foreground">
            7 días
          </span>
        )}
      </div>

      {mode === "week" ? (
        <div className="grid grid-cols-7 gap-1.5">
          {days.map((date) => {
            const key = toDateKey(date);
            const { done, total } = dayCompletion(habits, checks, key);
            const isToday = key === today;
            return (
              <Tooltip key={key}>
                <TooltipTrigger asChild>
                  <div
                    className={cn(
                      "flex min-h-16 flex-col items-center justify-center rounded-md px-1 py-2",
                      intensityClass(done, total),
                      isToday && "ring-2 ring-ring ring-offset-2 ring-offset-card",
                    )}
                  >
                    <span className="text-xs font-medium uppercase">
                      {WEEKDAY_HEADERS[date.getDay() === 0 ? 6 : date.getDay() - 1]}
                    </span>
                    <span className="font-display mt-1 text-lg leading-none tabular-nums">
                      {dayNumber(date)}
                    </span>
                    <span className="mt-1 text-xs tabular-nums opacity-80">
                      {total === 0 ? "—" : `${done}/${total}`}
                    </span>
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  {shortPrettyDate(date)}: {done} de {total} hábitos
                </TooltipContent>
              </Tooltip>
            );
          })}
        </div>
      ) : (
        <div className="min-w-0">
          <div className="mb-2 grid grid-cols-7 gap-1">
            {WEEKDAY_HEADERS.map((label) => (
              <div
                key={label}
                className="text-center text-xs font-medium text-muted-foreground"
              >
                {label}
              </div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {days.map((date) => {
              const key = toDateKey(date);
              const inMonth = isSameMonth(date, month);
              const { done, total } = dayCompletion(habits, checks, key);
              const isToday = key === today;
              const future = key > today;
              return (
                <Tooltip key={key}>
                  <TooltipTrigger asChild>
                    <div
                      className={cn(
                        "flex aspect-square items-center justify-center rounded-sm text-xs font-medium tabular-nums",
                        !inMonth && "opacity-30",
                        future
                          ? "bg-secondary/50 text-muted-foreground"
                          : intensityClass(done, total),
                        isToday &&
                          "ring-2 ring-ring ring-offset-1 ring-offset-card",
                      )}
                    >
                      {dayNumber(date)}
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    {inMonth
                      ? `${shortPrettyDate(date)}: ${done} de ${total} hábitos`
                      : shortPrettyDate(date)}
                  </TooltipContent>
                </Tooltip>
              );
            })}
          </div>
          <div className="mt-3 flex items-center justify-end gap-1.5 text-xs text-muted-foreground">
            <span>Menos</span>
            <span className="size-3 rounded-xs bg-secondary" />
            <span className="size-3 rounded-xs bg-primary/20" />
            <span className="size-3 rounded-xs bg-primary/45" />
            <span className="size-3 rounded-xs bg-primary/70" />
            <span className="size-3 rounded-xs bg-primary" />
            <span>Más</span>
          </div>
        </div>
      )}
    </section>
  );
}
