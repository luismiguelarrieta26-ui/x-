import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { AppHeader } from "@/components/app-header";
import { AppSkeleton } from "@/components/app-skeleton";
import { EmptyState } from "@/components/empty-state";
import { HabitDetailSheet } from "@/components/habit-detail-sheet";
import { HabitFormDialog } from "@/components/habit-form-dialog";
import { HabitGrid } from "@/components/habit-grid";
import { StreakCalendar } from "@/components/streak-calendar";
import { TodayPanel } from "@/components/today-panel";
import { hydrateHabitsStore, useHabitsStore } from "@/lib/habits/store";
import type { Habit, ViewMode } from "@/lib/habits/types";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const hydrated = useHabitsStore((s) => s.hydrated);
  const habits = useHabitsStore((s) => s.habits);
  const [mode, setMode] = useState<ViewMode>("week");
  const [month, setMonth] = useState(() => new Date());
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Habit | null>(null);
  const [detail, setDetail] = useState<Habit | null>(null);

  useEffect(() => {
    void hydrateHabitsStore();
  }, []);

  function openCreate() {
    setEditing(null);
    setFormOpen(true);
  }

  function openEdit(habit: Habit) {
    setDetail(null);
    setEditing(habit);
    setFormOpen(true);
  }

  return (
    <main className="mx-auto min-h-dvh max-w-5xl overflow-x-hidden px-4 py-6 sm:px-6 sm:py-8">
      <div className="stagger-in flex min-w-0 flex-col gap-5">
        {hydrated ? (
          <>
            <AppHeader mode={mode} onModeChange={setMode} onCreate={openCreate} />
            {habits.length === 0 ? (
              <EmptyState onCreate={openCreate} />
            ) : (
              <div className="grid min-w-0 items-start gap-5 lg:grid-cols-[minmax(0,20rem)_minmax(0,1fr)]">
                <TodayPanel onOpenHabit={setDetail} />
                <div className="flex min-w-0 flex-col gap-5">
                  <StreakCalendar
                    mode={mode}
                    month={month}
                    onMonthChange={setMonth}
                  />
                  <HabitGrid
                    mode={mode}
                    month={month}
                    onOpenHabit={setDetail}
                  />
                </div>
              </div>
            )}
          </>
        ) : (
          <AppSkeleton />
        )}
      </div>

      <HabitFormDialog
        open={formOpen}
        habit={editing}
        onOpenChange={(open) => {
          setFormOpen(open);
          if (!open) setEditing(null);
        }}
      />
      <HabitDetailSheet
        habit={detail}
        onClose={() => setDetail(null)}
        onEdit={openEdit}
      />
    </main>
  );
}
