export const HABIT_COLOR_IDS = [
  "forest",
  "clay",
  "slate",
  "ochre",
  "rose",
  "teal",
  "ink",
  "olive",
] as const;

export type HabitColorId = (typeof HABIT_COLOR_IDS)[number];

export const HABIT_ICON_IDS = [
  "droplets",
  "book",
  "walk",
  "brain",
  "moon",
  "dumbbell",
  "sun",
  "heart",
  "coffee",
  "pen",
  "music",
  "leaf",
] as const;

export type HabitIconId = (typeof HABIT_ICON_IDS)[number];

export type Habit = {
  id: string;
  name: string;
  color: HabitColorId;
  icon: HabitIconId;
  createdAt: string;
};

export type HabitsSnapshot = {
  habits: Habit[];
  checks: Record<string, string[]>;
  hasOnboarded: boolean;
};

export type ViewMode = "week" | "month";
